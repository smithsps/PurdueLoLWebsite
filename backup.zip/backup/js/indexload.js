/*$(window).load(function() {
  $('.jumbotron').hide();
  $('.overall').hide(); 
  $('.videoh').hide();
  $('.newsfade').hide();
  $('.toolsfade').hide();
  $('.contactfade').hide();
  $('.aboutfade').hide();
  $('.tournfade').hide();
  $('.fbfade').hide();
  $('.jumbotron').fadeIn(1500, function() {
      $('.overall').fadeIn(1500, function() {
      $('.tournfade').fadeIn(1500);
      $('.aboutfade').delay(200).fadeIn(1500);
      $('.contactfade').delay(400).fadeIn(1500);
      $('.toolsfade').delay(600).fadeIn(1500);
      $('.newsfade').delay(800).fadeIn(1500);
      $('.fbfade').delay(1000).fadeIn(1500);
  });
  });  
});*/